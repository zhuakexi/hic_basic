from __future__ import annotations

import re
import sys
from contextlib import contextmanager
from typing import Iterable, Iterator, Optional, Pattern, TextIO

DEFAULT_KEEP_PATTERN = r"^(chr)?([0-9]+|[XY])$"
NO_Y_PATTERN = r"^(chr)?([0-9]+|X)$"

_CHROM_HEADER_RE = re.compile(r"^#chromosome:\s+(\S+)")
_PAIRS_LINE_RE = re.compile(r"^\S+\t(\S+)\t\d+\t(\S+)\t\d+")
_SEGMENT_CHR_RE = re.compile(r"^([^\s!]+)")


def _compile_pattern(pattern: Optional[str], exclude_y: bool) -> Pattern[str]:
    if pattern is None:
        pattern = NO_Y_PATTERN if exclude_y else DEFAULT_KEEP_PATTERN
    return re.compile(pattern)


def _should_emit(line: str, chrom_re: Pattern[str]) -> bool:
    header_match = _CHROM_HEADER_RE.match(line)
    if header_match:
        return bool(chrom_re.match(header_match.group(1)))
    if line.startswith("#"):
        return True
    pairs_match = _PAIRS_LINE_RE.match(line)
    if pairs_match:
        chr1, chr2 = pairs_match.group(1), pairs_match.group(2)
        return bool(chrom_re.match(chr1) and chrom_re.match(chr2))
    fields = line.split("\t")
    if len(fields) <= 1:
        return True
    for field in fields[1:]:
        seg_match = _SEGMENT_CHR_RE.match(field)
        if seg_match is None or not chrom_re.match(seg_match.group(1)):
            return False
    return True


def chronly_lines(lines: Iterable[str], chrom_re: Pattern[str]) -> Iterator[str]:
    for raw_line in lines:
        stripped = raw_line.rstrip("\n")
        if _should_emit(stripped, chrom_re):
            yield raw_line


@contextmanager
def _open_reader(path: Optional[str]) -> Iterator[TextIO]:
    if path in (None, "-"):
        yield sys.stdin
    else:
        with open(path, "r", encoding="utf-8") as handle:
            yield handle


@contextmanager
def _open_writer(path: Optional[str]) -> Iterator[TextIO]:
    if path in (None, "-"):
        yield sys.stdout
    else:
        with open(path, "w", encoding="utf-8") as handle:
            yield handle


def cli(args) -> None:
    chrom_re = _compile_pattern(args.regex, args.exclude_y)
    with _open_reader(args.input_file) as reader, _open_writer(args.output_file) as writer:
        for line in chronly_lines(reader, chrom_re):
            writer.write(line)
