"""
``distances``
=============
"""
from .euclidean_distance import euclidean_distance_matrix  # noqa: F401
from .great_circle_distance import great_circle_distance_matrix  # noqa: F401
from .osrm_distance import osrm_distance_matrix  # noqa: F401


def tsplib_distance_matrix(*args, **kwargs):
    """Load optional TSPLIB support only when it is explicitly requested."""
    from .tsplib_distance import tsplib_distance_matrix as implementation

    return implementation(*args, **kwargs)
